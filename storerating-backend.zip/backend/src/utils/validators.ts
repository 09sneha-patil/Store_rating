export interface ValidationError {
  field: string;
  message: string;
}

export const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// 8-16 chars, at least one uppercase letter, at least one special character
export const PASSWORD_REGEX = /^(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?`~]).{8,16}$/;

export function validateName(name: unknown, fieldName: string = 'Name'): string | null {
  if (typeof name !== 'string') {
    return `${fieldName} is required and must be text.`;
  }
  const trimmed = name.trim();
  if (trimmed.length < 20 || trimmed.length > 60) {
    return `${fieldName} must be between 20 and 60 characters.`;
  }
  return null;
}

export function validateEmail(email: unknown): string | null {
  if (typeof email !== 'string') {
    return 'Email is required.';
  }
  const trimmed = email.trim();
  if (!trimmed) {
    return 'Email cannot be empty.';
  }
  if (!EMAIL_REGEX.test(trimmed)) {
    return 'Email must follow standard email validation rules (e.g., user@example.com).';
  }
  return null;
}

export function validatePassword(password: unknown): string | null {
  if (typeof password !== 'string') {
    return 'Password is required.';
  }
  if (!PASSWORD_REGEX.test(password)) {
    return 'Password must be 8-16 characters long and include at least one uppercase letter and one special character.';
  }
  return null;
}

export function validateAddress(address: unknown): string | null {
  if (typeof address !== 'string') {
    return 'Address is required.';
  }
  const trimmed = address.trim();
  if (trimmed.length === 0) {
    return 'Address cannot be empty.';
  }
  if (trimmed.length > 400) {
    return 'Address must not exceed 400 characters.';
  }
  return null;
}

export function validateRole(role: unknown): string | null {
  const validRoles = ['ADMIN', 'USER', 'STORE_OWNER'];
  if (typeof role !== 'string' || !validRoles.includes(role)) {
    return 'Role must be one of: ADMIN, USER, STORE_OWNER.';
  }
  return null;
}

export function validateRatingValue(rating: unknown): string | null {
  const num = Number(rating);
  if (!Number.isInteger(num) || num < 1 || num > 5) {
    return 'Rating must be an integer between 1 and 5.';
  }
  return null;
}
