import http from 'http';
import app from '../server';

const PORT = 5099;

function request(method: string, path: string, body?: any, token?: string): Promise<{ status: number; data: any }> {
  return new Promise((resolve, reject) => {
    const postData = body ? JSON.stringify(body) : undefined;
    const req = http.request(
      {
        hostname: 'localhost',
        port: PORT,
        path,
        method,
        headers: {
          'Content-Type': 'application/json',
          ...(postData ? { 'Content-Length': Buffer.byteLength(postData) } : {}),
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      },
      (res) => {
        let rawData = '';
        res.on('data', (chunk) => { rawData += chunk; });
        res.on('end', () => {
          let data;
          try {
            data = JSON.parse(rawData);
          } catch {
            data = rawData;
          }
          resolve({ status: res.statusCode || 500, data });
        });
      }
    );

    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function runTests() {
  const server = app.listen(PORT, async () => {
    console.log(`\n================ STARTING E2E INTEGRATION TESTS ================\n`);
    let passed = 0;
    let failed = 0;

    const assert = (condition: boolean, testName: string, extraInfo: any = '') => {
      if (condition) {
        console.log(`  ✓ PASS: ${testName}`);
        passed++;
      } else {
        console.error(`  ✗ FAIL: ${testName}`, extraInfo);
        failed++;
      }
    };

    try {
      // 1. Health Check
      const health = await request('GET', '/api/health');
      assert(health.status === 200 && health.data.status === 'UP', 'Health check returns UP');

      // 2. Normal User Signup Validation
      // Test name too short (< 20 chars)
      const shortNameReg = await request('POST', '/api/auth/register', {
        name: 'Short Name',
        email: 'test.short@example.com',
        address: '123 Fake Street',
        password: 'Password@123',
      });
      assert(shortNameReg.status === 400, 'Rejects registration with Name < 20 chars');

      // Test invalid password (no special char)
      const invalidPassReg = await request('POST', '/api/auth/register', {
        name: 'Valid Name Between Twenty And Sixty Chars',
        email: 'test.pass@example.com',
        address: '123 Fake Street',
        password: 'Password123', // missing special char
      });
      assert(invalidPassReg.status === 400, 'Rejects registration with password missing special char');

      // Test valid normal user registration
      const validReg = await request('POST', '/api/auth/register', {
        name: 'Alexander Hamilton Junior',
        email: `hamilton.${Date.now()}@example.com`,
        address: '57 Wall Street, Financial District, New York, NY 10005',
        password: 'Hamilton@1776',
      });
      assert(validReg.status === 201 && validReg.data.user.role === 'USER', 'Normal user registers successfully with USER role');
      const newUserToken = validReg.data.token;

      // 3. Single Login System for All Roles
      // Admin Login
      const adminLogin = await request('POST', '/api/auth/login', {
        email: 'admin@storerate.com',
        password: 'Admin@1234',
      });
      assert(adminLogin.status === 200 && adminLogin.data.user.role === 'ADMIN', 'System Administrator logs in successfully');
      const adminToken = adminLogin.data.token;

      // Store Owner Login
      const ownerLogin = await request('POST', '/api/auth/login', {
        email: 'owner.david@example.com',
        password: 'Owner@1234',
      });
      assert(ownerLogin.status === 200 && ownerLogin.data.user.role === 'STORE_OWNER', 'Store Owner logs in successfully');
      const ownerToken = ownerLogin.data.token;

      // Normal User Login
      const userLogin = await request('POST', '/api/auth/login', {
        email: 'alice@example.com',
        password: 'User@1234',
      });
      assert(userLogin.status === 200 && userLogin.data.user.role === 'USER', 'Normal User logs in successfully');
      const aliceToken = userLogin.data.token;

      // 4. Admin Dashboard Metrics
      const adminStats = await request('GET', '/api/admin/dashboard', undefined, adminToken);
      assert(
        adminStats.status === 200 &&
        typeof adminStats.data.data.totalUsers === 'number' &&
        typeof adminStats.data.data.totalStores === 'number' &&
        typeof adminStats.data.data.totalRatings === 'number',
        'Admin dashboard returns total users, stores, and ratings metrics'
      );

      // 5. Admin Store & User Listing & Sorting
      const adminStores = await request('GET', '/api/admin/stores?sortBy=name&order=asc', undefined, adminToken);
      assert(adminStores.status === 200 && Array.isArray(adminStores.data.data), 'Admin can list stores with sorting and ratings');

      const adminUsers = await request('GET', '/api/admin/users?sortBy=role&order=asc', undefined, adminToken);
      assert(adminUsers.status === 200 && Array.isArray(adminUsers.data.data), 'Admin can list users with sorting');

      // Check if Store Owner has their rating displayed
      const storeOwnerUser = adminUsers.data.data.find((u: any) => u.role === 'STORE_OWNER' && u.storeName);
      assert(
        storeOwnerUser && typeof storeOwnerUser.rating === 'number',
        'Admin user listing displays store rating for Store Owner users'
      );

      // 6. Admin Add New Store
      const newStore = await request('POST', '/api/admin/stores', {
        name: 'The Organic Greenway Superstore',
        email: 'contact@organicgreenway.com',
        address: '400 Greenway Avenue, Silicon Valley, CA 94025',
      }, adminToken);
      assert(newStore.status === 201 && newStore.data.data.id, 'Admin can add a new store');
      const newStoreId = newStore.data.data.id;

      // 7. Normal User View Stores & Ratings
      const storesForUser = await request('GET', '/api/stores', undefined, aliceToken);
      assert(
        storesForUser.status === 200 &&
        storesForUser.data.data[0].overallRating !== undefined &&
        storesForUser.data.data[0].myRating !== undefined,
        'Normal user can view store listings with overall rating and user submitted rating'
      );

      // Search stores by name and address
      const searchResult = await request('GET', '/api/stores?search=Organic', undefined, aliceToken);
      assert(searchResult.status === 200 && searchResult.data.data.length > 0, 'Normal user can search stores');

      // 8. Normal User Submit Rating (1-5)
      const submitRating = await request('POST', '/api/stores/ratings', {
        storeId: newStoreId,
        rating: 5,
      }, newUserToken);
      assert(submitRating.status === 200 && submitRating.data.data.myRating === 5, 'Normal user can submit a rating between 1 and 5');

      // Modify Submitted Rating
      const modifyRating = await request('POST', '/api/stores/ratings', {
        storeId: newStoreId,
        rating: 4,
      }, newUserToken);
      assert(
        modifyRating.status === 200 &&
        modifyRating.data.isModified === true &&
        modifyRating.data.data.myRating === 4,
        'Normal user can modify their submitted rating'
      );

      // 9. Store Owner Dashboard
      const ownerDash = await request('GET', '/api/owner/dashboard?sortBy=date&order=desc', undefined, ownerToken);
      assert(
        ownerDash.status === 200 &&
        ownerDash.data.hasStore === true &&
        typeof ownerDash.data.data.averageRating === 'number' &&
        Array.isArray(ownerDash.data.data.ratingUsers),
        'Store Owner can see average store rating and list of users who submitted ratings'
      );

      // 10. Password Change
      const changePass = await request('PUT', '/api/auth/change-password', {
        currentPassword: 'Hamilton@1776',
        newPassword: 'Hamilton@1789',
      }, newUserToken);
      assert(changePass.status === 200, 'User can update password after logging in');

      // Verify login with updated password
      const reLogin = await request('POST', '/api/auth/login', {
        email: validReg.data.user.email,
        password: 'Hamilton@1789',
      });
      assert(reLogin.status === 200, 'User can log in with new password');

    } catch (err: any) {
      console.error('Unhandled test execution error:', err);
      failed++;
    } finally {
      console.log(`\n================ TEST SUMMARY ================`);
      console.log(`Total Passed: ${passed}`);
      console.log(`Total Failed: ${failed}`);
      console.log(`==============================================\n`);

      server.close(() => {
        process.exit(failed > 0 ? 1 : 0);
      });
    }
  });
}

runTests();
