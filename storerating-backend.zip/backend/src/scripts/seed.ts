import bcrypt from 'bcryptjs';
import { pool } from '../config/database';

async function seed() {
  console.log('Seeding initial data into PostgreSQL...');
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // Clean tables first to allow idempotent re-seeding
    await client.query('TRUNCATE TABLE ratings, stores, users RESTART IDENTITY CASCADE;');

    const adminPasswordHash = await bcrypt.hash('Admin@1234', 10);
    const userPasswordHash = await bcrypt.hash('User@1234', 10);
    const ownerPasswordHash = await bcrypt.hash('Owner@1234', 10);

    // 1. Seed Users
    console.log('Seeding users...');
    const usersResult = await client.query(`
      INSERT INTO users (name, email, password_hash, address, role) VALUES
      (
        'System Administrator Officer',
        'admin@storerate.com',
        $1,
        '100 Global Headquarters Boulevard, Tech Plaza, Suite 500, Metro City',
        'ADMIN'
      ),
      (
        'David William Richardson',
        'owner.david@example.com',
        $2,
        '88 Market Street, Financial District, San Francisco, CA 94105',
        'STORE_OWNER'
      ),
      (
        'Eleanor Grace Henderson',
        'owner.eleanor@example.com',
        $2,
        '210 Broadway Avenue, Capitol Hill, Seattle, WA 98102',
        'STORE_OWNER'
      ),
      (
        'Alice Elizabeth Johnson',
        'alice@example.com',
        $3,
        '742 Evergreen Terrace, West Springfield, OR 97477',
        'USER'
      ),
      (
        'Bob Alexander Martinez',
        'bob@example.com',
        $3,
        '123 Main Street, Apartment 4B, New York, NY 10001',
        'USER'
      ),
      (
        'Catherine Diane Miller',
        'catherine@example.com',
        $3,
        '456 Elmwood Avenue, North Chicago, IL 60611',
        'USER'
      )
      RETURNING id, name, email, role;
    `, [adminPasswordHash, ownerPasswordHash, userPasswordHash]);

    const usersMap: Record<string, number> = {};
    for (const u of usersResult.rows) {
      usersMap[u.email] = u.id;
    }

    // 2. Seed Stores
    console.log('Seeding stores...');
    const storesResult = await client.query(`
      INSERT INTO stores (name, email, address, owner_id) VALUES
      (
        'Downtown Fresh Organic Market',
        'contact@downtownfresh.com',
        '88 Market Street, Financial District, San Francisco, CA 94105',
        $1
      ),
      (
        'Grand Central Artisan Bakery',
        'hello@grandcentralbakery.com',
        '210 Broadway Avenue, Capitol Hill, Seattle, WA 98102',
        $2
      ),
      (
        'Pioneer Valley Book & Coffee',
        'info@pioneervalleybooks.com',
        '15 University Avenue, Back Bay, Boston, MA 02115',
        NULL
      )
      RETURNING id, name;
    `, [usersMap['owner.david@example.com'], usersMap['owner.eleanor@example.com']]);

    const store1Id = storesResult.rows[0].id;
    const store2Id = storesResult.rows[1].id;
    const store3Id = storesResult.rows[2].id;

    // 3. Seed Ratings
    console.log('Seeding ratings...');
    await client.query(`
      INSERT INTO ratings (user_id, store_id, rating) VALUES
      ($1, $4, 5),
      ($1, $5, 4),
      ($2, $4, 4),
      ($2, $5, 5),
      ($3, $4, 5),
      ($3, $6, 3);
    `, [
      usersMap['alice@example.com'],
      usersMap['bob@example.com'],
      usersMap['catherine@example.com'],
      store1Id,
      store2Id,
      store3Id,
    ]);

    await client.query('COMMIT');
    console.log('Seeding completed successfully!');
    console.log('\n--- Default Credentials ---');
    console.log('Administrator: admin@storerate.com / Admin@1234');
    console.log('Store Owner 1: owner.david@example.com / Owner@1234');
    console.log('Store Owner 2: owner.eleanor@example.com / Owner@1234');
    console.log('Normal User 1: alice@example.com / User@1234');
    console.log('Normal User 2: bob@example.com / User@1234');
    console.log('Normal User 3: catherine@example.com / User@1234');
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error seeding database:', error);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

seed();
