import { Response } from 'express';
import { db } from '../config/database';
import { AuthenticatedRequest } from '../middleware/auth.middleware';

export async function getOwnerDashboard(req: AuthenticatedRequest, res: Response): Promise<void> {
  if (!req.user) {
    res.status(401).json({ success: false, message: 'Unauthorized' });
    return;
  }

  const { sortBy = 'date', order = 'desc' } = req.query;

  try {
    // Find store owned by current user
    const storeResult = await db.query(
      `SELECT id, name, email, address, created_at
       FROM stores WHERE owner_id = $1`,
      [req.user.id]
    );

    if (storeResult.rows.length === 0) {
      res.json({
        success: true,
        hasStore: false,
        message: 'No store is currently assigned to your store owner account.',
        data: {
          store: null,
          averageRating: 0.0,
          totalRatings: 0,
          ratingUsers: [],
        },
      });
      return;
    }

    const store = storeResult.rows[0];

    // Compute store overall average rating & count
    const statsResult = await db.query(
      `SELECT
        COALESCE(ROUND(AVG(rating)::numeric, 1), 0.0) AS average_rating,
        COUNT(*)::int AS total_ratings
       FROM ratings WHERE store_id = $1`,
      [store.id]
    );

    const averageRating = parseFloat(statsResult.rows[0].average_rating);
    const totalRatings = statsResult.rows[0].total_ratings;

    // Sorting users list
    const allowedSortFields: Record<string, string> = {
      name: 'u.name',
      email: 'u.email',
      rating: 'r.rating',
      date: 'r.updated_at',
      id: 'r.id',
    };

    const sortColumn = allowedSortFields[String(sortBy).toLowerCase()] || 'r.updated_at';
    const sortDirection = String(order).toLowerCase() === 'asc' ? 'ASC' : 'DESC';

    // List of users who submitted ratings for this store
    const usersRatingsResult = await db.query(
      `SELECT
        r.id AS rating_id,
        r.rating,
        r.updated_at,
        u.id AS user_id,
        u.name AS user_name,
        u.email AS user_email,
        u.address AS user_address
       FROM ratings r
       JOIN users u ON r.user_id = u.id
       WHERE r.store_id = $1
       ORDER BY ${sortColumn} ${sortDirection}`,
      [store.id]
    );

    res.json({
      success: true,
      hasStore: true,
      data: {
        store: {
          id: store.id,
          name: store.name,
          email: store.email,
          address: store.address,
        },
        averageRating,
        totalRatings,
        ratingUsers: usersRatingsResult.rows.map((row) => ({
          ratingId: row.rating_id,
          userId: row.user_id,
          name: row.user_name,
          email: row.user_email,
          address: row.user_address,
          rating: row.rating,
          date: row.updated_at,
        })),
      },
    });
  } catch (error: any) {
    console.error('getOwnerDashboard error:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve store owner dashboard data.' });
  }
}
