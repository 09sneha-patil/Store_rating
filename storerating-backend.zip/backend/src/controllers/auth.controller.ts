import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { db } from '../config/database';
import { generateToken } from '../utils/jwt';
import {
  validateName,
  validateEmail,
  validatePassword,
  validateAddress,
} from '../utils/validators';
import { AuthenticatedRequest } from '../middleware/auth.middleware';

export async function register(req: Request, res: Response): Promise<void> {
  const { name, email, password, address } = req.body;

  // Validation
  const errors: { field: string; message: string }[] = [];
  const nameErr = validateName(name, 'Name');
  if (nameErr) errors.push({ field: 'name', message: nameErr });

  const emailErr = validateEmail(email);
  if (emailErr) errors.push({ field: 'email', message: emailErr });

  const passwordErr = validatePassword(password);
  if (passwordErr) errors.push({ field: 'password', message: passwordErr });

  const addressErr = validateAddress(address);
  if (addressErr) errors.push({ field: 'address', message: addressErr });

  if (errors.length > 0) {
    res.status(400).json({ success: false, errors, message: 'Validation failed.' });
    return;
  }

  const normalizedEmail = String(email).trim().toLowerCase();

  try {
    // Check existing email
    const existing = await db.query('SELECT id FROM users WHERE LOWER(email) = $1', [normalizedEmail]);
    if (existing.rows.length > 0) {
      res.status(409).json({
        success: false,
        message: 'A user with this email address already exists. Please log in or use another email.',
      });
      return;
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const insertResult = await db.query(
      `INSERT INTO users (name, email, password_hash, address, role)
       VALUES ($1, $2, $3, $4, 'USER')
       RETURNING id, name, email, address, role, created_at`,
      [name.trim(), normalizedEmail, passwordHash, address.trim()]
    );

    const user = insertResult.rows[0];
    const token = generateToken({
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name,
    });

    res.status(201).json({
      success: true,
      message: 'Account registered successfully.',
      token,
      user,
    });
  } catch (error: any) {
    console.error('Registration error:', error);
    res.status(500).json({ success: false, message: 'Internal server error while registering account.' });
  }
}

export async function login(req: Request, res: Response): Promise<void> {
  const { email, password } = req.body;

  if (!email || !password) {
    res.status(400).json({
      success: false,
      message: 'Email and password are required.',
    });
    return;
  }

  const normalizedEmail = String(email).trim().toLowerCase();

  try {
    const userResult = await db.query(
      `SELECT id, name, email, password_hash, address, role, created_at
       FROM users WHERE LOWER(email) = $1`,
      [normalizedEmail]
    );

    if (userResult.rows.length === 0) {
      res.status(401).json({
        success: false,
        message: 'Invalid email or password.',
      });
      return;
    }

    const user = userResult.rows[0];
    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      res.status(401).json({
        success: false,
        message: 'Invalid email or password.',
      });
      return;
    }

    const token = generateToken({
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name,
    });

    res.json({
      success: true,
      message: 'Login successful.',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        address: user.address,
        role: user.role,
        createdAt: user.created_at,
      },
    });
  } catch (error: any) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Internal server error during login.' });
  }
}

export async function getMe(req: AuthenticatedRequest, res: Response): Promise<void> {
  if (!req.user) {
    res.status(401).json({ success: false, message: 'Unauthorized' });
    return;
  }

  try {
    const userResult = await db.query(
      `SELECT id, name, email, address, role, created_at
       FROM users WHERE id = $1`,
      [req.user.id]
    );

    if (userResult.rows.length === 0) {
      res.status(404).json({ success: false, message: 'User not found.' });
      return;
    }

    res.json({
      success: true,
      user: userResult.rows[0],
    });
  } catch (error: any) {
    console.error('getMe error:', error);
    res.status(500).json({ success: false, message: 'Internal server error.' });
  }
}

export async function changePassword(req: AuthenticatedRequest, res: Response): Promise<void> {
  if (!req.user) {
    res.status(401).json({ success: false, message: 'Unauthorized' });
    return;
  }

  const { currentPassword, newPassword } = req.body;

  if (!currentPassword || !newPassword) {
    res.status(400).json({
      success: false,
      message: 'Both current password and new password are required.',
    });
    return;
  }

  const passwordErr = validatePassword(newPassword);
  if (passwordErr) {
    res.status(400).json({
      success: false,
      message: passwordErr,
      errors: [{ field: 'newPassword', message: passwordErr }],
    });
    return;
  }

  try {
    const userResult = await db.query(
      `SELECT id, password_hash FROM users WHERE id = $1`,
      [req.user.id]
    );

    if (userResult.rows.length === 0) {
      res.status(404).json({ success: false, message: 'User not found.' });
      return;
    }

    const isMatch = await bcrypt.compare(currentPassword, userResult.rows[0].password_hash);
    if (!isMatch) {
      res.status(400).json({
        success: false,
        message: 'The current password you entered is incorrect.',
      });
      return;
    }

    const newHash = await bcrypt.hash(newPassword, 10);
    await db.query(
      `UPDATE users SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2`,
      [newHash, req.user.id]
    );

    res.json({
      success: true,
      message: 'Password updated successfully.',
    });
  } catch (error: any) {
    console.error('changePassword error:', error);
    res.status(500).json({ success: false, message: 'Internal server error updating password.' });
  }
}
