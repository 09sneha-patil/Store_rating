import { Response } from 'express';
import { db } from '../config/database';
import { AuthenticatedRequest } from '../middleware/auth.middleware';
import { validateRatingValue } from '../utils/validators';

export async function getStoresForUsers(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const userId = req.user ? req.user.id : null;
    const { search, name, address, sortBy = 'name', order = 'asc' } = req.query;

    const conditions: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    // Search matches either name or address
    if (search && typeof search === 'string' && search.trim()) {
      conditions.push(`(s.name ILIKE $${paramIndex} OR s.address ILIKE $${paramIndex})`);
      values.push(`%${search.trim()}%`);
      paramIndex++;
    }

    if (name && typeof name === 'string' && name.trim()) {
      conditions.push(`s.name ILIKE $${paramIndex}`);
      values.push(`%${name.trim()}%`);
      paramIndex++;
    }

    if (address && typeof address === 'string' && address.trim()) {
      conditions.push(`s.address ILIKE $${paramIndex}`);
      values.push(`%${address.trim()}%`);
      paramIndex++;
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const allowedSortFields: Record<string, string> = {
      name: 's.name',
      address: 's.address',
      overallrating: 'overall_rating',
      rating: 'overall_rating',
      myrating: 'my_rating',
      id: 's.id',
    };

    const sortColumn = allowedSortFields[String(sortBy).toLowerCase()] || 's.name';
    const sortDirection = String(order).toLowerCase() === 'desc' ? 'DESC' : 'ASC';

    // Build user rating parameter
    let userJoin = '';
    if (userId) {
      userJoin = `LEFT JOIN ratings my_r ON s.id = my_r.store_id AND my_r.user_id = $${paramIndex}`;
      values.push(userId);
      paramIndex++;
    }

    const sql = `
      SELECT
        s.id,
        s.name,
        s.email,
        s.address,
        COALESCE(ROUND(AVG(all_r.rating)::numeric, 1), 0.0) AS overall_rating,
        COUNT(all_r.id)::int AS rating_count
        ${userId ? ', my_r.rating AS my_rating, my_r.updated_at AS my_rated_at' : ', NULL AS my_rating, NULL AS my_rated_at'}
      FROM stores s
      LEFT JOIN ratings all_r ON s.id = all_r.store_id
      ${userJoin}
      ${whereClause}
      GROUP BY s.id ${userId ? ', my_r.rating, my_r.updated_at' : ''}
      ORDER BY ${sortColumn} ${sortDirection} NULLS LAST, s.id ASC
    `;

    const result = await db.query(sql, values);

    res.json({
      success: true,
      data: result.rows.map((row) => ({
        id: row.id,
        name: row.name,
        email: row.email,
        address: row.address,
        overallRating: parseFloat(row.overall_rating),
        ratingCount: row.rating_count,
        myRating: row.my_rating !== null ? parseInt(row.my_rating, 10) : null,
        myRatedAt: row.my_rated_at || null,
      })),
    });
  } catch (error: any) {
    console.error('getStoresForUsers error:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve store listings.' });
  }
}

export async function submitOrUpdateRating(req: AuthenticatedRequest, res: Response): Promise<void> {
  if (!req.user) {
    res.status(401).json({ success: false, message: 'Unauthorized' });
    return;
  }

  const { storeId, rating } = req.body;
  const targetStoreId = parseInt(storeId || req.params.storeId, 10);

  if (isNaN(targetStoreId)) {
    res.status(400).json({ success: false, message: 'Invalid store ID.' });
    return;
  }

  const ratingErr = validateRatingValue(rating);
  if (ratingErr) {
    res.status(400).json({ success: false, message: ratingErr });
    return;
  }

  const numericRating = parseInt(rating, 10);

  try {
    // Check if store exists
    const storeExists = await db.query('SELECT id, name FROM stores WHERE id = $1', [targetStoreId]);
    if (storeExists.rows.length === 0) {
      res.status(404).json({ success: false, message: 'Store not found.' });
      return;
    }

    // Check if user already submitted a rating
    const existing = await db.query(
      'SELECT id, rating FROM ratings WHERE user_id = $1 AND store_id = $2',
      [req.user.id, targetStoreId]
    );

    const isModify = existing.rows.length > 0;

    const upsertResult = await db.query(
      `INSERT INTO ratings (user_id, store_id, rating, updated_at)
       VALUES ($1, $2, $3, CURRENT_TIMESTAMP)
       ON CONFLICT (user_id, store_id)
       DO UPDATE SET rating = EXCLUDED.rating, updated_at = CURRENT_TIMESTAMP
       RETURNING id, user_id, store_id, rating, updated_at`,
      [req.user.id, targetStoreId, numericRating]
    );

    // Fetch new overall rating of the store
    const newStatsResult = await db.query(
      `SELECT COALESCE(ROUND(AVG(rating)::numeric, 1), 0.0) AS overall_rating, COUNT(*)::int AS count
       FROM ratings WHERE store_id = $1`,
      [targetStoreId]
    );

    res.json({
      success: true,
      message: isModify ? 'Rating modified successfully.' : 'Rating submitted successfully.',
      isModified: isModify,
      data: {
        storeId: targetStoreId,
        myRating: upsertResult.rows[0].rating,
        overallRating: parseFloat(newStatsResult.rows[0].overall_rating),
        ratingCount: newStatsResult.rows[0].count,
      },
    });
  } catch (error: any) {
    console.error('submitOrUpdateRating error:', error);
    res.status(500).json({ success: false, message: 'Failed to record rating.' });
  }
}

export async function getMyRatings(req: AuthenticatedRequest, res: Response): Promise<void> {
  if (!req.user) {
    res.status(401).json({ success: false, message: 'Unauthorized' });
    return;
  }

  try {
    const result = await db.query(
      `SELECT
        r.id,
        r.store_id,
        s.name AS store_name,
        s.address AS store_address,
        r.rating,
        r.updated_at
      FROM ratings r
      JOIN stores s ON r.store_id = s.id
      WHERE r.user_id = $1
      ORDER BY r.updated_at DESC`,
      [req.user.id]
    );

    res.json({
      success: true,
      data: result.rows.map((row) => ({
        id: row.id,
        storeId: row.store_id,
        storeName: row.store_name,
        storeAddress: row.store_address,
        rating: row.rating,
        updatedAt: row.updated_at,
      })),
    });
  } catch (error: any) {
    console.error('getMyRatings error:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve submitted ratings.' });
  }
}
