import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { db } from '../config/database';
import {
  validateName,
  validateEmail,
  validatePassword,
  validateAddress,
  validateRole,
} from '../utils/validators';

export async function getDashboardStats(req: Request, res: Response): Promise<void> {
  try {
    const userCountResult = await db.query('SELECT COUNT(*) AS total_users FROM users');
    const storeCountResult = await db.query('SELECT COUNT(*) AS total_stores FROM stores');
    const ratingCountResult = await db.query('SELECT COUNT(*) AS total_ratings FROM ratings');

    const roleBreakdownResult = await db.query(`
      SELECT role, COUNT(*) AS count
      FROM users
      GROUP BY role
    `);

    const roleCounts: Record<string, number> = {
      ADMIN: 0,
      USER: 0,
      STORE_OWNER: 0,
    };
    for (const row of roleBreakdownResult.rows) {
      roleCounts[row.role] = parseInt(row.count, 10);
    }

    res.json({
      success: true,
      data: {
        totalUsers: parseInt(userCountResult.rows[0].total_users, 10),
        totalStores: parseInt(storeCountResult.rows[0].total_stores, 10),
        totalRatings: parseInt(ratingCountResult.rows[0].total_ratings, 10),
        roleCounts,
      },
    });
  } catch (error: any) {
    console.error('getDashboardStats error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch dashboard statistics.' });
  }
}

export async function getStores(req: Request, res: Response): Promise<void> {
  try {
    const { name, email, address, sortBy = 'name', order = 'asc' } = req.query;

    const conditions: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    if (name && typeof name === 'string' && name.trim()) {
      conditions.push(`s.name ILIKE $${paramIndex}`);
      values.push(`%${name.trim()}%`);
      paramIndex++;
    }

    if (email && typeof email === 'string' && email.trim()) {
      conditions.push(`s.email ILIKE $${paramIndex}`);
      values.push(`%${email.trim()}%`);
      paramIndex++;
    }

    if (address && typeof address === 'string' && address.trim()) {
      conditions.push(`s.address ILIKE $${paramIndex}`);
      values.push(`%${address.trim()}%`);
      paramIndex++;
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const allowedSortFields: Record<string, string> = {
      id: 's.id',
      name: 's.name',
      email: 's.email',
      address: 's.address',
      rating: 'average_rating',
      created_at: 's.created_at',
    };

    const sortColumn = allowedSortFields[String(sortBy).toLowerCase()] || 's.name';
    const sortDirection = String(order).toLowerCase() === 'desc' ? 'DESC' : 'ASC';

    const sql = `
      SELECT
        s.id,
        s.name,
        s.email,
        s.address,
        s.owner_id,
        u.name AS owner_name,
        u.email AS owner_email,
        COALESCE(ROUND(AVG(r.rating)::numeric, 1), 0.0) AS rating,
        COUNT(r.id)::int AS rating_count
      FROM stores s
      LEFT JOIN users u ON s.owner_id = u.id
      LEFT JOIN ratings r ON s.id = r.store_id
      ${whereClause}
      GROUP BY s.id, u.name, u.email
      ORDER BY ${sortColumn} ${sortDirection} NULLS LAST, s.id ASC
    `;

    const result = await db.query(sql, values);

    res.json({
      success: true,
      data: result.rows.map((row) => ({
        id: row.id,
        name: row.name,
        email: row.email,
        address: row.address,
        ownerId: row.owner_id,
        ownerName: row.owner_name,
        ownerEmail: row.owner_email,
        rating: parseFloat(row.rating),
        ratingCount: row.rating_count,
      })),
    });
  } catch (error: any) {
    console.error('getStores error:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve stores.' });
  }
}

export async function addStore(req: Request, res: Response): Promise<void> {
  const { name, email, address, ownerId } = req.body;

  const errors: { field: string; message: string }[] = [];
  const nameErr = validateName(name, 'Store Name');
  if (nameErr) errors.push({ field: 'name', message: nameErr });

  const emailErr = validateEmail(email);
  if (emailErr) errors.push({ field: 'email', message: emailErr });

  const addressErr = validateAddress(address);
  if (addressErr) errors.push({ field: 'address', message: addressErr });

  if (errors.length > 0) {
    res.status(400).json({ success: false, errors, message: 'Validation failed.' });
    return;
  }

  try {
    let validatedOwnerId: number | null = null;
    if (ownerId) {
      const ownerCheck = await db.query(
        "SELECT id, role FROM users WHERE id = $1 AND role = 'STORE_OWNER'",
        [ownerId]
      );
      if (ownerCheck.rows.length === 0) {
        res.status(400).json({
          success: false,
          message: 'Specified owner ID does not exist or is not a Store Owner.',
        });
        return;
      }
      validatedOwnerId = ownerCheck.rows[0].id;
    }

    const insertResult = await db.query(
      `INSERT INTO stores (name, email, address, owner_id)
       VALUES ($1, $2, $3, $4)
       RETURNING id, name, email, address, owner_id, created_at`,
      [name.trim(), email.trim().toLowerCase(), address.trim(), validatedOwnerId]
    );

    res.status(201).json({
      success: true,
      message: 'Store created successfully.',
      data: insertResult.rows[0],
    });
  } catch (error: any) {
    console.error('addStore error:', error);
    res.status(500).json({ success: false, message: 'Failed to create store.' });
  }
}

export async function getUsers(req: Request, res: Response): Promise<void> {
  try {
    const { name, email, address, role, sortBy = 'name', order = 'asc' } = req.query;

    const conditions: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    if (name && typeof name === 'string' && name.trim()) {
      conditions.push(`u.name ILIKE $${paramIndex}`);
      values.push(`%${name.trim()}%`);
      paramIndex++;
    }

    if (email && typeof email === 'string' && email.trim()) {
      conditions.push(`u.email ILIKE $${paramIndex}`);
      values.push(`%${email.trim()}%`);
      paramIndex++;
    }

    if (address && typeof address === 'string' && address.trim()) {
      conditions.push(`u.address ILIKE $${paramIndex}`);
      values.push(`%${address.trim()}%`);
      paramIndex++;
    }

    if (role && typeof role === 'string' && role.trim()) {
      conditions.push(`u.role = $${paramIndex}`);
      values.push(role.trim().toUpperCase());
      paramIndex++;
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const allowedSortFields: Record<string, string> = {
      id: 'u.id',
      name: 'u.name',
      email: 'u.email',
      address: 'u.address',
      role: 'u.role',
      rating: 'store_rating',
      created_at: 'u.created_at',
    };

    const sortColumn = allowedSortFields[String(sortBy).toLowerCase()] || 'u.name';
    const sortDirection = String(order).toLowerCase() === 'desc' ? 'DESC' : 'ASC';

    const sql = `
      SELECT
        u.id,
        u.name,
        u.email,
        u.address,
        u.role,
        u.created_at,
        st.id AS store_id,
        st.name AS store_name,
        ROUND(AVG(r.rating)::numeric, 1) AS store_rating,
        COUNT(r.id)::int AS rating_count
      FROM users u
      LEFT JOIN stores st ON st.owner_id = u.id
      LEFT JOIN ratings r ON st.id = r.store_id
      ${whereClause}
      GROUP BY u.id, st.id, st.name
      ORDER BY ${sortColumn} ${sortDirection} NULLS LAST, u.id ASC
    `;

    const result = await db.query(sql, values);

    res.json({
      success: true,
      data: result.rows.map((row) => ({
        id: row.id,
        name: row.name,
        email: row.email,
        address: row.address,
        role: row.role,
        createdAt: row.created_at,
        storeId: row.store_id || null,
        storeName: row.store_name || null,
        // Rating is provided if the user is a Store Owner
        rating: row.role === 'STORE_OWNER' ? (row.store_rating ? parseFloat(row.store_rating) : null) : null,
        ratingCount: row.role === 'STORE_OWNER' ? row.rating_count : null,
      })),
    });
  } catch (error: any) {
    console.error('getUsers error:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve users.' });
  }
}

export async function addUser(req: Request, res: Response): Promise<void> {
  const { name, email, password, address, role } = req.body;

  const errors: { field: string; message: string }[] = [];
  const nameErr = validateName(name, 'Name');
  if (nameErr) errors.push({ field: 'name', message: nameErr });

  const emailErr = validateEmail(email);
  if (emailErr) errors.push({ field: 'email', message: emailErr });

  const passwordErr = validatePassword(password);
  if (passwordErr) errors.push({ field: 'password', message: passwordErr });

  const addressErr = validateAddress(address);
  if (addressErr) errors.push({ field: 'address', message: addressErr });

  const roleErr = validateRole(role);
  if (roleErr) errors.push({ field: 'role', message: roleErr });

  if (errors.length > 0) {
    res.status(400).json({ success: false, errors, message: 'Validation failed.' });
    return;
  }

  const normalizedEmail = String(email).trim().toLowerCase();

  try {
    const existing = await db.query('SELECT id FROM users WHERE LOWER(email) = $1', [normalizedEmail]);
    if (existing.rows.length > 0) {
      res.status(409).json({
        success: false,
        message: 'A user with this email address already exists.',
      });
      return;
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const insertResult = await db.query(
      `INSERT INTO users (name, email, password_hash, address, role)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, name, email, address, role, created_at`,
      [name.trim(), normalizedEmail, passwordHash, address.trim(), role]
    );

    res.status(201).json({
      success: true,
      message: 'User created successfully.',
      data: insertResult.rows[0],
    });
  } catch (error: any) {
    console.error('addUser error:', error);
    res.status(500).json({ success: false, message: 'Failed to add user.' });
  }
}

export async function getUserDetails(req: Request, res: Response): Promise<void> {
  const { id } = req.params;

  try {
    const userResult = await db.query(
      `SELECT
        u.id,
        u.name,
        u.email,
        u.address,
        u.role,
        u.created_at,
        st.id AS store_id,
        st.name AS store_name,
        st.email AS store_email,
        st.address AS store_address,
        ROUND(AVG(r.rating)::numeric, 1) AS store_rating,
        COUNT(r.id)::int AS rating_count
      FROM users u
      LEFT JOIN stores st ON st.owner_id = u.id
      LEFT JOIN ratings r ON st.id = r.store_id
      WHERE u.id = $1
      GROUP BY u.id, st.id, st.name, st.email, st.address`,
      [id]
    );

    if (userResult.rows.length === 0) {
      res.status(404).json({ success: false, message: 'User not found.' });
      return;
    }

    const row = userResult.rows[0];
    res.json({
      success: true,
      data: {
        id: row.id,
        name: row.name,
        email: row.email,
        address: row.address,
        role: row.role,
        createdAt: row.created_at,
        store: row.store_id
          ? {
              id: row.store_id,
              name: row.store_name,
              email: row.store_email,
              address: row.store_address,
              rating: row.store_rating ? parseFloat(row.store_rating) : null,
              ratingCount: row.rating_count,
            }
          : null,
        rating: row.role === 'STORE_OWNER' ? (row.store_rating ? parseFloat(row.store_rating) : null) : null,
      },
    });
  } catch (error: any) {
    console.error('getUserDetails error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch user details.' });
  }
}

export async function getStoreOwners(req: Request, res: Response): Promise<void> {
  try {
    const result = await db.query(
      `SELECT id, name, email, address FROM users WHERE role = 'STORE_OWNER' ORDER BY name ASC`
    );
    res.json({
      success: true,
      data: result.rows,
    });
  } catch (error: any) {
    console.error('getStoreOwners error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch store owners.' });
  }
}
