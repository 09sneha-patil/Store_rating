import { Router } from 'express';
import {
  getDashboardStats,
  getStores,
  addStore,
  getUsers,
  addUser,
  getUserDetails,
  getStoreOwners,
} from '../controllers/admin.controller';
import { authenticate, authorize } from '../middleware/auth.middleware';

const router = Router();

// All admin routes require authentication and ADMIN role
router.use(authenticate, authorize('ADMIN'));

router.get('/dashboard', getDashboardStats);
router.get('/stores', getStores);
router.post('/stores', addStore);
router.get('/users', getUsers);
router.post('/users', addUser);
router.get('/users/:id', getUserDetails);
router.get('/store-owners', getStoreOwners);

export default router;
