import { Router } from 'express';
import { getOwnerDashboard } from '../controllers/owner.controller';
import { authenticate, authorize } from '../middleware/auth.middleware';

const router = Router();

router.use(authenticate, authorize('STORE_OWNER'));
router.get('/dashboard', getOwnerDashboard);

export default router;
