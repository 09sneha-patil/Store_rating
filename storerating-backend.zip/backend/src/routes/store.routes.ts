import { Router } from 'express';
import {
  getStoresForUsers,
  submitOrUpdateRating,
  getMyRatings,
} from '../controllers/store.controller';
import { authenticate, authorize } from '../middleware/auth.middleware';

const router = Router();

// Store listings can be viewed by authenticated users
router.get('/', authenticate, getStoresForUsers);

// Ratings submission and modifications by normal users
router.post('/ratings', authenticate, authorize('USER'), submitOrUpdateRating);
router.put('/ratings/:storeId', authenticate, authorize('USER'), submitOrUpdateRating);
router.get('/ratings/my', authenticate, authorize('USER'), getMyRatings);

export default router;
