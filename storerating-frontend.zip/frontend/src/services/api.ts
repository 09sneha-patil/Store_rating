const API_BASE_URL = '/api';

export function getAuthToken(): string | null {
  return localStorage.getItem('token');
}

export function setAuthToken(token: string | null): void {
  if (token) {
    localStorage.setItem('token', token);
  } else {
    localStorage.removeItem('token');
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({ message: 'Server returned non-JSON response' }));

  if (!response.ok) {
    const errorMsg = data.message || (data.errors && data.errors[0]?.message) || 'Request failed';
    const error = new Error(errorMsg);
    (error as any).status = response.status;
    (error as any).data = data;
    throw error;
  }

  return data;
}

export const api = {
  // Auth
  login: (credentials: { email: string; password: string }) =>
    request<{ success: boolean; token: string; user: any; message: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    }),

  register: (payload: { name: string; email: string; address: string; password: string }) =>
    request<{ success: boolean; token: string; user: any; message: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getMe: () =>
    request<{ success: boolean; user: any }>('/auth/me'),

  changePassword: (payload: { currentPassword: string; newPassword: string }) =>
    request<{ success: boolean; message: string }>('/auth/change-password', {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),

  // Admin
  getDashboardStats: () =>
    request<{ success: boolean; data: any }>('/admin/dashboard'),

  getAdminStores: (params?: { name?: string; email?: string; address?: string; sortBy?: string; order?: string }) => {
    const query = new URLSearchParams(params as any).toString();
    return request<{ success: boolean; data: any[] }>(`/admin/stores${query ? `?${query}` : ''}`);
  },

  addStore: (payload: { name: string; email: string; address: string; ownerId?: number | null }) =>
    request<{ success: boolean; data: any; message: string }>('/admin/stores', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getAdminUsers: (params?: { name?: string; email?: string; address?: string; role?: string; sortBy?: string; order?: string }) => {
    const query = new URLSearchParams(params as any).toString();
    return request<{ success: boolean; data: any[] }>(`/admin/users${query ? `?${query}` : ''}`);
  },

  addUser: (payload: { name: string; email: string; password: string; address: string; role: string }) =>
    request<{ success: boolean; data: any; message: string }>('/admin/users', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getUserDetails: (id: number) =>
    request<{ success: boolean; data: any }>(`/admin/users/${id}`),

  getStoreOwners: () =>
    request<{ success: boolean; data: any[] }>('/admin/store-owners'),

  // Normal User / Stores
  getUserStores: (params?: { search?: string; name?: string; address?: string; sortBy?: string; order?: string }) => {
    const query = new URLSearchParams(params as any).toString();
    return request<{ success: boolean; data: any[] }>(`/stores${query ? `?${query}` : ''}`);
  },

  submitRating: (storeId: number, rating: number) =>
    request<{ success: boolean; message: string; data: any }>('/stores/ratings', {
      method: 'POST',
      body: JSON.stringify({ storeId, rating }),
    }),

  getMyRatings: () =>
    request<{ success: boolean; data: any[] }>('/stores/ratings/my'),

  // Store Owner
  getOwnerDashboard: (params?: { sortBy?: string; order?: string }) => {
    const query = new URLSearchParams(params as any).toString();
    return request<{ success: boolean; hasStore: boolean; message?: string; data: any }>(
      `/owner/dashboard${query ? `?${query}` : ''}`
    );
  },
};
