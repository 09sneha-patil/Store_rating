export type UserRole = 'ADMIN' | 'USER' | 'STORE_OWNER';

export interface User {
  id: number;
  name: string;
  email: string;
  address: string;
  role: UserRole;
  createdAt?: string;
  storeId?: number | null;
  storeName?: string | null;
  rating?: number | null;
  ratingCount?: number | null;
}

export interface Store {
  id: number;
  name: string;
  email: string;
  address: string;
  ownerId?: number | null;
  ownerName?: string | null;
  ownerEmail?: string | null;
  rating?: number;
  overallRating?: number;
  ratingCount?: number;
  myRating?: number | null;
  myRatedAt?: string | null;
}

export interface RatingRecord {
  ratingId: number;
  userId: number;
  name: string;
  email: string;
  address?: string;
  rating: number;
  date: string;
}

export interface DashboardStats {
  totalUsers: number;
  totalStores: number;
  totalRatings: number;
  roleCounts?: {
    ADMIN: number;
    USER: number;
    STORE_OWNER: number;
  };
}
