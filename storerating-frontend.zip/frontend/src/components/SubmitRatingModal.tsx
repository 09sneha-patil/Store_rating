import React, { useState, useEffect } from 'react';
import { X, Star, CheckCircle2, AlertCircle } from 'lucide-react';
import { Store } from '../types';
import { api } from '../services/api';
import { StarRating } from './StarRating';

interface SubmitRatingModalProps {
  isOpen: boolean;
  store: Store | null;
  onClose: () => void;
  onSuccess: (storeId: number, newRating: number, newOverall: number, newCount: number) => void;
}

export const SubmitRatingModal: React.FC<SubmitRatingModalProps> = ({
  isOpen,
  store,
  onClose,
  onSuccess,
}) => {
  const [rating, setRating] = useState<number>(5);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (store) {
      setRating(store.myRating || 5);
      setError(null);
      setSuccess(null);
    }
  }, [store]);

  if (!isOpen || !store) return null;

  const isModifying = Boolean(store.myRating);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (rating < 1 || rating > 5) {
      setError('Rating must be between 1 and 5.');
      return;
    }

    setLoading(true);
    try {
      const res = await api.submitRating(store.id, rating);
      setSuccess(res.message || (isModifying ? 'Rating updated!' : 'Rating submitted!'));
      setTimeout(() => {
        onSuccess(store.id, res.data.myRating, res.data.overallRating, res.data.ratingCount);
        onClose();
      }, 1000);
    } catch (err: any) {
      setError(err.message || 'Failed to submit rating.');
    } finally {
      setLoading(false);
    }
  };

  const ratingDescriptions: Record<number, string> = {
    1: '1 Star - Poor / Needs improvement',
    2: '2 Stars - Fair / Average at best',
    3: '3 Stars - Good / Met expectations',
    4: '4 Stars - Very Good / Highly satisfied',
    5: '5 Stars - Outstanding / Excellent!',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-50 text-amber-500 rounded-lg">
              <Star className="w-5 h-5 fill-amber-400" />
            </div>
            <h3 className="text-lg font-bold text-slate-800">
              {isModifying ? 'Modify Your Rating' : 'Submit Store Rating'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-sm">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="flex items-center gap-2 p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl text-sm">
              <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
              <span>{success}</span>
            </div>
          )}

          {/* Store Info preview */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/60">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Store</div>
            <div className="font-bold text-slate-800 text-base">{store.name}</div>
            <div className="text-xs text-slate-500 mt-0.5 line-clamp-1">{store.address}</div>
            <div className="mt-2 text-xs flex items-center gap-2">
              <span className="text-slate-500">Current overall rating:</span>
              <span className="font-semibold text-slate-800">
                {store.overallRating ? `${store.overallRating} ★` : 'No ratings yet'}
              </span>
            </div>
          </div>

          {/* Interactive Star Picker */}
          <div className="text-center py-2">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-3">
              Select Your Rating (1 - 5)
            </label>
            <div className="flex justify-center mb-2">
              <StarRating
                value={rating}
                interactive={true}
                size="lg"
                onChange={(val) => setRating(val)}
              />
            </div>
            <p className="text-sm font-medium text-amber-600 h-6">
              {ratingDescriptions[rating]}
            </p>

            {/* Quick-number selection pills */}
            <div className="flex justify-center gap-2 mt-3">
              {[1, 2, 3, 4, 5].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setRating(val)}
                  className={`w-9 h-9 rounded-lg text-sm font-bold transition-all ${
                    rating === val
                      ? 'bg-amber-400 text-white shadow-md shadow-amber-200 scale-105'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {val}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              className="px-4 py-2.5 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 shadow-sm shadow-indigo-200 transition-all disabled:opacity-50"
            >
              {loading
                ? 'Submitting...'
                : isModifying
                ? 'Update Rating'
                : 'Submit Rating'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
