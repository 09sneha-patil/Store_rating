import React, { useState, useEffect } from 'react';
import { X, User, Mail, MapPin, Shield, ShoppingBag, Star, AlertCircle } from 'lucide-react';
import { api } from '../services/api';
import { StarRating } from './StarRating';

interface UserDetailsModalProps {
  userId: number | null;
  isOpen: boolean;
  onClose: () => void;
}

export const UserDetailsModal: React.FC<UserDetailsModalProps> = ({ userId, isOpen, onClose }) => {
  const [userData, setUserData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && userId) {
      loadUserDetails(userId);
    } else {
      setUserData(null);
    }
  }, [isOpen, userId]);

  const loadUserDetails = async (id: number) => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getUserDetails(id);
      if (res.success) {
        setUserData(res.data);
      } else {
        setError('Failed to load user details.');
      }
    } catch (err: any) {
      setError(err.message || 'Error loading user details.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
              <User className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-800">User Details</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {loading && (
            <div className="py-12 text-center text-slate-500 text-sm">
              <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
              Loading user profile...
            </div>
          )}

          {error && (
            <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-sm">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {!loading && userData && (
            <div className="space-y-5">
              {/* Profile Card */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/60 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="text-base font-bold text-slate-900">{userData.name}</h4>
                    <span className="text-xs text-slate-400">ID #{userData.id}</span>
                  </div>
                  <div>
                    {userData.role === 'ADMIN' && (
                      <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-700 border border-purple-200 flex items-center gap-1">
                        <Shield className="w-3.5 h-3.5" /> Administrator
                      </span>
                    )}
                    {userData.role === 'STORE_OWNER' && (
                      <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                        <ShoppingBag className="w-3.5 h-3.5" /> Store Owner
                      </span>
                    )}
                    {userData.role === 'USER' && (
                      <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-700 border border-blue-200 flex items-center gap-1">
                        <User className="w-3.5 h-3.5" /> Normal User
                      </span>
                    )}
                  </div>
                </div>

                <div className="space-y-2 pt-2 border-t border-slate-200/60 text-sm">
                  <div className="flex items-center gap-2 text-slate-600">
                    <Mail className="w-4 h-4 text-slate-400 flex-shrink-0" />
                    <span>{userData.email}</span>
                  </div>
                  <div className="flex items-start gap-2 text-slate-600">
                    <MapPin className="w-4 h-4 text-slate-400 flex-shrink-0 mt-0.5" />
                    <span>{userData.address}</span>
                  </div>
                </div>
              </div>

              {/* Requirement: If the user is a Store Owner, their Rating should also be displayed */}
              {userData.role === 'STORE_OWNER' && (
                <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200/70">
                  <div className="flex items-center gap-2 text-amber-900 font-bold text-sm mb-2">
                    <Star className="w-4 h-4 text-amber-500 fill-amber-400" />
                    Store Owner Rating Details
                  </div>

                  {userData.store ? (
                    <div className="space-y-2 text-sm text-slate-700">
                      <div className="flex justify-between items-center py-1 border-b border-amber-200/50">
                        <span className="text-slate-500 text-xs uppercase font-medium">Assigned Store</span>
                        <span className="font-semibold">{userData.store.name}</span>
                      </div>
                      <div className="flex justify-between items-center py-1 border-b border-amber-200/50">
                        <span className="text-slate-500 text-xs uppercase font-medium">Store Email</span>
                        <span>{userData.store.email}</span>
                      </div>
                      <div className="flex justify-between items-center py-1">
                        <span className="text-slate-500 text-xs uppercase font-medium">Average Rating</span>
                        <div className="flex items-center gap-2">
                          <StarRating value={userData.rating} interactive={false} size="sm" />
                          <span className="font-bold text-slate-900">
                            {userData.rating !== null ? `${userData.rating} / 5.0` : 'No ratings yet'}
                          </span>
                          <span className="text-xs text-slate-500">
                            ({userData.store.ratingCount || 0} reviews)
                          </span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-amber-800">
                      This Store Owner does not have a store assigned yet. No rating available.
                    </p>
                  )}
                </div>
              )}

              <div className="flex justify-end pt-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-slate-800 hover:bg-slate-900 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
