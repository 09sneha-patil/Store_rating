import React from 'react';
import { ChevronUp, ChevronDown, ChevronsUpDown } from 'lucide-react';

interface SortableHeaderProps {
  label: string;
  field: string;
  currentSort: string;
  currentOrder: 'asc' | 'desc';
  onSort: (field: string) => void;
  className?: string;
}

export const SortableHeader: React.FC<SortableHeaderProps> = ({
  label,
  field,
  currentSort,
  currentOrder,
  onSort,
  className = '',
}) => {
  const isActive = currentSort.toLowerCase() === field.toLowerCase();

  return (
    <th
      onClick={() => onSort(field)}
      className={`px-4 py-3.5 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider cursor-pointer select-none hover:bg-slate-100/80 transition-colors ${className}`}
      title={`Click to sort by ${label}`}
    >
      <div className="flex items-center gap-1.5 group">
        <span>{label}</span>
        <span className="text-slate-400 group-hover:text-slate-700">
          {isActive ? (
            currentOrder === 'asc' ? (
              <ChevronUp className="w-4 h-4 text-indigo-600" />
            ) : (
              <ChevronDown className="w-4 h-4 text-indigo-600" />
            )
          ) : (
            <ChevronsUpDown className="w-3.5 h-3.5 opacity-50 group-hover:opacity-100" />
          )}
        </span>
      </div>
    </th>
  );
};
