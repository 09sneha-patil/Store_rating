import React, { useState, useEffect } from 'react';
import {
  Users,
  Store,
  Star,
  Plus,
  Search,
  Filter,
  Eye,
  RefreshCw,
  ShoppingBag,
  Shield,
  User as UserIcon,
} from 'lucide-react';
import { Navbar } from '../components/Navbar';
import { SortableHeader } from '../components/SortableHeader';
import { StarRating } from '../components/StarRating';
import { AddStoreModal } from '../components/AddStoreModal';
import { AddUserModal } from '../components/AddUserModal';
import { UserDetailsModal } from '../components/UserDetailsModal';
import { api } from '../services/api';
import { DashboardStats, Store as StoreType, User as UserType } from '../types';

export const AdminDashboardPage: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [activeTab, setActiveTab] = useState<'stores' | 'users'>('stores');

  // Stores State
  const [stores, setStores] = useState<StoreType[]>([]);
  const [storesLoading, setStoresLoading] = useState(false);
  const [storeFilterName, setStoreFilterName] = useState('');
  const [storeFilterEmail, setStoreFilterEmail] = useState('');
  const [storeFilterAddress, setStoreFilterAddress] = useState('');
  const [storeSortBy, setStoreSortBy] = useState('name');
  const [storeOrder, setStoreOrder] = useState<'asc' | 'desc'>('asc');

  // Users State
  const [users, setUsers] = useState<UserType[]>([]);
  const [usersLoading, setUsersLoading] = useState(false);
  const [userFilterName, setUserFilterName] = useState('');
  const [userFilterEmail, setUserFilterEmail] = useState('');
  const [userFilterAddress, setUserFilterAddress] = useState('');
  const [userFilterRole, setUserFilterRole] = useState('');
  const [userSortBy, setUserSortBy] = useState('name');
  const [userOrder, setUserOrder] = useState<'asc' | 'desc'>('asc');

  // Modals
  const [isAddStoreModalOpen, setIsAddStoreModalOpen] = useState(false);
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [isUserDetailsModalOpen, setIsUserDetailsModalOpen] = useState(false);

  useEffect(() => {
    loadDashboardStats();
  }, []);

  useEffect(() => {
    if (activeTab === 'stores') {
      loadStores();
    } else {
      loadUsers();
    }
  }, [
    activeTab,
    storeFilterName,
    storeFilterEmail,
    storeFilterAddress,
    storeSortBy,
    storeOrder,
    userFilterName,
    userFilterEmail,
    userFilterAddress,
    userFilterRole,
    userSortBy,
    userOrder,
  ]);

  const loadDashboardStats = async () => {
    try {
      const res = await api.getDashboardStats();
      if (res.success) {
        setStats(res.data);
      }
    } catch (err) {
      console.error('Failed to load stats', err);
    }
  };

  const loadStores = async () => {
    setStoresLoading(true);
    try {
      const res = await api.getAdminStores({
        name: storeFilterName,
        email: storeFilterEmail,
        address: storeFilterAddress,
        sortBy: storeSortBy,
        order: storeOrder,
      });
      if (res.success) {
        setStores(res.data);
      }
    } catch (err) {
      console.error('Failed to load stores', err);
    } finally {
      setStoresLoading(false);
    }
  };

  const loadUsers = async () => {
    setUsersLoading(true);
    try {
      const res = await api.getAdminUsers({
        name: userFilterName,
        email: userFilterEmail,
        address: userFilterAddress,
        role: userFilterRole,
        sortBy: userSortBy,
        order: userOrder,
      });
      if (res.success) {
        setUsers(res.data);
      }
    } catch (err) {
      console.error('Failed to load users', err);
    } finally {
      setUsersLoading(false);
    }
  };

  const handleStoreSort = (field: string) => {
    if (storeSortBy.toLowerCase() === field.toLowerCase()) {
      setStoreOrder(storeOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setStoreSortBy(field);
      setStoreOrder('asc');
    }
  };

  const handleUserSort = (field: string) => {
    if (userSortBy.toLowerCase() === field.toLowerCase()) {
      setUserOrder(userOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setUserSortBy(field);
      setUserOrder('asc');
    }
  };

  const handleViewUser = (id: number) => {
    setSelectedUserId(id);
    setIsUserDetailsModalOpen(true);
  };

  const clearStoreFilters = () => {
    setStoreFilterName('');
    setStoreFilterEmail('');
    setStoreFilterAddress('');
  };

  const clearUserFilters = () => {
    setUserFilterName('');
    setUserFilterEmail('');
    setUserFilterAddress('');
    setUserFilterRole('');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              System Administration
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Manage platform stores, users, ratings, and view global statistics
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setIsAddStoreModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm shadow-indigo-200 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Add Store</span>
            </button>
            <button
              onClick={() => setIsAddUserModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 shadow-sm transition-all"
            >
              <Plus className="w-4 h-4 text-indigo-600" />
              <span>Add User</span>
            </button>
          </div>
        </div>

        {/* Dashboard Metrics (Requirement: Total users, total stores, total ratings) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Total Users
                </span>
                <div className="text-3xl font-black text-slate-900 mt-1">
                  {stats ? stats.totalUsers : '...'}
                </div>
              </div>
              <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
                <Users className="w-6 h-6" />
              </div>
            </div>
            {stats?.roleCounts && (
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-3 text-xs text-slate-500">
                <span>{stats.roleCounts.USER} Users</span>
                <span>•</span>
                <span>{stats.roleCounts.STORE_OWNER} Owners</span>
                <span>•</span>
                <span>{stats.roleCounts.ADMIN} Admins</span>
              </div>
            )}
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Total Stores
                </span>
                <div className="text-3xl font-black text-slate-900 mt-1">
                  {stats ? stats.totalStores : '...'}
                </div>
              </div>
              <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
                <Store className="w-6 h-6" />
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500">
              Stores registered on the platform
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Submitted Ratings
                </span>
                <div className="text-3xl font-black text-slate-900 mt-1">
                  {stats ? stats.totalRatings : '...'}
                </div>
              </div>
              <div className="p-3 bg-amber-50 text-amber-500 rounded-xl">
                <Star className="w-6 h-6 fill-amber-400" />
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500">
              Community ratings submitted (1-5 ★)
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="border-b border-slate-200 flex items-center justify-between">
          <nav className="flex space-x-6">
            <button
              onClick={() => setActiveTab('stores')}
              className={`py-4 px-1 inline-flex items-center gap-2 border-b-2 font-bold text-sm transition-all ${
                activeTab === 'stores'
                  ? 'border-indigo-600 text-indigo-600'
                  : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
              }`}
            >
              <Store className="w-4 h-4" />
              <span>Registered Stores ({stores.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('users')}
              className={`py-4 px-1 inline-flex items-center gap-2 border-b-2 font-bold text-sm transition-all ${
                activeTab === 'users'
                  ? 'border-indigo-600 text-indigo-600'
                  : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Users & Owners ({users.length})</span>
            </button>
          </nav>

          <button
            onClick={() => {
              loadDashboardStats();
              activeTab === 'stores' ? loadStores() : loadUsers();
            }}
            title="Refresh Table"
            className="p-2 text-slate-400 hover:text-indigo-600 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {/* TAB 1: STORES */}
        {activeTab === 'stores' && (
          <div className="space-y-4">
            {/* Filter Bar (Requirement: Can apply filters on listings based on Name, Email, Address) */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                  <Filter className="w-3.5 h-3.5 text-indigo-600" /> Filter Stores
                </span>
                {(storeFilterName || storeFilterEmail || storeFilterAddress) && (
                  <button
                    onClick={clearStoreFilters}
                    className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold"
                  >
                    Clear Filters
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={storeFilterName}
                    onChange={(e) => setStoreFilterName(e.target.value)}
                    placeholder="Filter by Store Name..."
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={storeFilterEmail}
                    onChange={(e) => setStoreFilterEmail(e.target.value)}
                    placeholder="Filter by Store Email..."
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={storeFilterAddress}
                    onChange={(e) => setStoreFilterAddress(e.target.value)}
                    placeholder="Filter by Address..."
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>
              </div>
            </div>

            {/* Stores Table (Requirement: Name, Email, Address, Rating with sorting) */}
            <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-slate-200 text-sm">
                  <thead className="bg-slate-50/75">
                    <tr>
                      <SortableHeader
                        label="Store Name"
                        field="name"
                        currentSort={storeSortBy}
                        currentOrder={storeOrder}
                        onSort={handleStoreSort}
                      />
                      <SortableHeader
                        label="Email"
                        field="email"
                        currentSort={storeSortBy}
                        currentOrder={storeOrder}
                        onSort={handleStoreSort}
                      />
                      <SortableHeader
                        label="Address"
                        field="address"
                        currentSort={storeSortBy}
                        currentOrder={storeOrder}
                        onSort={handleStoreSort}
                      />
                      <SortableHeader
                        label="Rating"
                        field="rating"
                        currentSort={storeSortBy}
                        currentOrder={storeOrder}
                        onSort={handleStoreSort}
                      />
                      <th className="px-4 py-3.5 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                        Store Owner
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 bg-white">
                    {storesLoading ? (
                      <tr>
                        <td colSpan={5} className="py-12 text-center text-slate-400">
                          <div className="w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                          Loading stores...
                        </td>
                      </tr>
                    ) : stores.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-12 text-center text-slate-400">
                          No stores match your current filters.
                        </td>
                      </tr>
                    ) : (
                      stores.map((s) => (
                        <tr key={s.id} className="hover:bg-slate-50/60 transition-colors">
                          <td className="px-4 py-3.5 font-bold text-slate-900">
                            {s.name}
                          </td>
                          <td className="px-4 py-3.5 text-slate-600 font-mono text-xs">
                            {s.email}
                          </td>
                          <td className="px-4 py-3.5 text-slate-600 max-w-xs truncate" title={s.address}>
                            {s.address}
                          </td>
                          <td className="px-4 py-3.5">
                            <div className="flex items-center gap-2">
                              <StarRating value={s.rating} interactive={false} size="sm" />
                              <span className="font-bold text-slate-800">
                                {s.rating ? s.rating.toFixed(1) : '0.0'}
                              </span>
                              <span className="text-xs text-slate-400">
                                ({s.ratingCount || 0})
                              </span>
                            </div>
                          </td>
                          <td className="px-4 py-3.5 text-slate-600 text-xs">
                            {s.ownerName ? (
                              <span className="inline-flex items-center gap-1 font-medium text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                                <ShoppingBag className="w-3 h-3" />
                                {s.ownerName}
                              </span>
                            ) : (
                              <span className="text-slate-400 italic">Unassigned</span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: USERS */}
        {activeTab === 'users' && (
          <div className="space-y-4">
            {/* Filter Bar (Requirement: Filters for Name, Email, Address, Role) */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                  <Filter className="w-3.5 h-3.5 text-indigo-600" /> Filter Users
                </span>
                {(userFilterName || userFilterEmail || userFilterAddress || userFilterRole) && (
                  <button
                    onClick={clearUserFilters}
                    className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold"
                  >
                    Clear Filters
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={userFilterName}
                    onChange={(e) => setUserFilterName(e.target.value)}
                    placeholder="Filter by Name..."
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={userFilterEmail}
                    onChange={(e) => setUserFilterEmail(e.target.value)}
                    placeholder="Filter by Email..."
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={userFilterAddress}
                    onChange={(e) => setUserFilterAddress(e.target.value)}
                    placeholder="Filter by Address..."
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <select
                    value={userFilterRole}
                    onChange={(e) => setUserFilterRole(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 bg-white"
                  >
                    <option value="">All Roles</option>
                    <option value="USER">Normal User</option>
                    <option value="ADMIN">Administrator</option>
                    <option value="STORE_OWNER">Store Owner</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Users Table (Requirement: Name, Email, Address, Role, and If Store Owner their Rating) */}
            <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-slate-200 text-sm">
                  <thead className="bg-slate-50/75">
                    <tr>
                      <SortableHeader
                        label="User Name"
                        field="name"
                        currentSort={userSortBy}
                        currentOrder={userOrder}
                        onSort={handleUserSort}
                      />
                      <SortableHeader
                        label="Email"
                        field="email"
                        currentSort={userSortBy}
                        currentOrder={userOrder}
                        onSort={handleUserSort}
                      />
                      <SortableHeader
                        label="Address"
                        field="address"
                        currentSort={userSortBy}
                        currentOrder={userOrder}
                        onSort={handleUserSort}
                      />
                      <SortableHeader
                        label="Role"
                        field="role"
                        currentSort={userSortBy}
                        currentOrder={userOrder}
                        onSort={handleUserSort}
                      />
                      <SortableHeader
                        label="Store Rating (Owners)"
                        field="rating"
                        currentSort={userSortBy}
                        currentOrder={userOrder}
                        onSort={handleUserSort}
                      />
                      <th className="px-4 py-3.5 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">
                        Action
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 bg-white">
                    {usersLoading ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-slate-400">
                          <div className="w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                          Loading users...
                        </td>
                      </tr>
                    ) : users.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-slate-400">
                          No users match your current filters.
                        </td>
                      </tr>
                    ) : (
                      users.map((u) => (
                        <tr key={u.id} className="hover:bg-slate-50/60 transition-colors">
                          <td className="px-4 py-3.5 font-bold text-slate-900">
                            {u.name}
                          </td>
                          <td className="px-4 py-3.5 text-slate-600 font-mono text-xs">
                            {u.email}
                          </td>
                          <td className="px-4 py-3.5 text-slate-600 max-w-xs truncate" title={u.address}>
                            {u.address}
                          </td>
                          <td className="px-4 py-3.5">
                            {u.role === 'ADMIN' && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-700 border border-purple-200">
                                <Shield className="w-3 h-3" /> Admin
                              </span>
                            )}
                            {u.role === 'STORE_OWNER' && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700 border border-emerald-200">
                                <ShoppingBag className="w-3 h-3" /> Store Owner
                              </span>
                            )}
                            {u.role === 'USER' && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-700 border border-blue-200">
                                <UserIcon className="w-3 h-3" /> Normal User
                              </span>
                            )}
                          </td>
                          {/* Requirement: If user is Store Owner, their Rating should also be displayed */}
                          <td className="px-4 py-3.5">
                            {u.role === 'STORE_OWNER' ? (
                              u.rating !== null && u.rating !== undefined ? (
                                <div className="flex items-center gap-1.5">
                                  <StarRating value={u.rating} interactive={false} size="sm" />
                                  <span className="font-bold text-slate-800 text-xs">
                                    {u.rating.toFixed(1)} ★
                                  </span>
                                  <span className="text-[11px] text-slate-400">
                                    ({u.ratingCount || 0})
                                  </span>
                                </div>
                              ) : (
                                <span className="text-xs text-slate-400 italic">No ratings / unassigned</span>
                              )
                            ) : (
                              <span className="text-slate-300 text-xs">—</span>
                            )}
                          </td>
                          <td className="px-4 py-3.5 text-right">
                            <button
                              onClick={() => handleViewUser(u.id)}
                              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50 transition-colors"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>Details</span>
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Modals */}
      <AddStoreModal
        isOpen={isAddStoreModalOpen}
        onClose={() => setIsAddStoreModalOpen(false)}
        onSuccess={() => {
          loadStores();
          loadDashboardStats();
        }}
      />

      <AddUserModal
        isOpen={isAddUserModalOpen}
        onClose={() => setIsAddUserModalOpen(false)}
        onSuccess={() => {
          loadUsers();
          loadDashboardStats();
        }}
      />

      <UserDetailsModal
        userId={selectedUserId}
        isOpen={isUserDetailsModalOpen}
        onClose={() => {
          setIsUserDetailsModalOpen(false);
          setSelectedUserId(null);
        }}
      />
    </div>
  );
};
