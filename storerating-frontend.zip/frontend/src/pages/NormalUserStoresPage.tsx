import React, { useState, useEffect } from 'react';
import { Search, Star, Edit3, PlusCircle, Store as StoreIcon, RefreshCw, Filter } from 'lucide-react';
import { Navbar } from '../components/Navbar';
import { SortableHeader } from '../components/SortableHeader';
import { StarRating } from '../components/StarRating';
import { SubmitRatingModal } from '../components/SubmitRatingModal';
import { api } from '../services/api';
import { Store } from '../types';

export const NormalUserStoresPage: React.FC = () => {
  const [stores, setStores] = useState<Store[]>([]);
  const [loading, setLoading] = useState(false);

  // Search & Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [nameFilter, setNameFilter] = useState('');
  const [addressFilter, setAddressFilter] = useState('');

  // Sorting state
  const [sortBy, setSortBy] = useState('name');
  const [order, setOrder] = useState<'asc' | 'desc'>('asc');

  // Rating Modal state
  const [selectedStore, setSelectedStore] = useState<Store | null>(null);
  const [isRatingModalOpen, setIsRatingModalOpen] = useState(false);

  useEffect(() => {
    loadStores();
  }, [searchTerm, nameFilter, addressFilter, sortBy, order]);

  const loadStores = async () => {
    setLoading(true);
    try {
      const res = await api.getUserStores({
        search: searchTerm,
        name: nameFilter,
        address: addressFilter,
        sortBy,
        order,
      });
      if (res.success) {
        setStores(res.data);
      }
    } catch (err) {
      console.error('Failed to load stores', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (field: string) => {
    if (sortBy.toLowerCase() === field.toLowerCase()) {
      setOrder(order === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setOrder('asc');
    }
  };

  const handleOpenRatingModal = (store: Store) => {
    setSelectedStore(store);
    setIsRatingModalOpen(true);
  };

  const handleRatingSuccess = (storeId: number, newMyRating: number, newOverall: number, newCount: number) => {
    setStores((prevStores) =>
      prevStores.map((s) => {
        if (s.id === storeId) {
          return {
            ...s,
            myRating: newMyRating,
            overallRating: newOverall,
            ratingCount: newCount,
          };
        }
        return s;
      })
    );
  };

  const clearFilters = () => {
    setSearchTerm('');
    setNameFilter('');
    setAddressFilter('');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {/* Banner */}
        <div className="bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-800 rounded-3xl p-6 sm:p-8 text-white shadow-xl shadow-indigo-200/50">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-white/20 text-white backdrop-blur-sm mb-3">
              <Star className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
              Community Store Ratings
            </span>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Explore & Rate Registered Stores
            </h1>
            <p className="mt-2 text-indigo-100 text-sm sm:text-base leading-relaxed">
              Browse stores across your neighborhood, see real community ratings, and share your experience by submitting or modifying your ratings.
            </p>
          </div>
        </div>

        {/* Search & Filter Toolbar (Requirement: Search stores by Name and Address) */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-indigo-600" /> Search & Filter Stores
            </span>
            {(searchTerm || nameFilter || addressFilter) && (
              <button
                onClick={clearFilters}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold"
              >
                Reset Search
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Quick General Search */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by keyword..."
                className="w-full pl-10 pr-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              />
            </div>

            {/* Filter by Name */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
              <input
                type="text"
                value={nameFilter}
                onChange={(e) => setNameFilter(e.target.value)}
                placeholder="Search by Store Name..."
                className="w-full pl-10 pr-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              />
            </div>

            {/* Filter by Address */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
              <input
                type="text"
                value={addressFilter}
                onChange={(e) => setAddressFilter(e.target.value)}
                placeholder="Search by Address..."
                className="w-full pl-10 pr-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Stores Table Header / Actions */}
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <StoreIcon className="w-5 h-5 text-indigo-600" />
            <span>Stores Catalog ({stores.length})</span>
          </h2>

          <button
            onClick={loadStores}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:text-indigo-600 hover:bg-slate-100 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>

        {/* Stores Table (Requirement: Store Name, Address, Overall Rating, User's Submitted Rating, Option to submit/modify) */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 text-sm">
              <thead className="bg-slate-50/75">
                <tr>
                  <SortableHeader
                    label="Store Name"
                    field="name"
                    currentSort={sortBy}
                    currentOrder={order}
                    onSort={handleSort}
                  />
                  <SortableHeader
                    label="Address"
                    field="address"
                    currentSort={sortBy}
                    currentOrder={order}
                    onSort={handleSort}
                  />
                  <SortableHeader
                    label="Overall Rating"
                    field="overallRating"
                    currentSort={sortBy}
                    currentOrder={order}
                    onSort={handleSort}
                  />
                  <SortableHeader
                    label="Your Submitted Rating"
                    field="myRating"
                    currentSort={sortBy}
                    currentOrder={order}
                    onSort={handleSort}
                  />
                  <th className="px-4 py-3.5 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Rating Action
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {loading ? (
                  <tr>
                    <td colSpan={5} className="py-16 text-center text-slate-400">
                      <div className="w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                      Searching stores...
                    </td>
                  </tr>
                ) : stores.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-16 text-center text-slate-400">
                      No stores found matching your search criteria.
                    </td>
                  </tr>
                ) : (
                  stores.map((s) => {
                    const hasSubmittedRating = s.myRating !== null && s.myRating !== undefined;

                    return (
                      <tr key={s.id} className="hover:bg-slate-50/60 transition-colors">
                        {/* Store Name */}
                        <td className="px-4 py-4 font-bold text-slate-900">
                          {s.name}
                        </td>

                        {/* Address */}
                        <td className="px-4 py-4 text-slate-600 max-w-sm truncate" title={s.address}>
                          {s.address}
                        </td>

                        {/* Overall Rating */}
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-2">
                            <StarRating value={s.overallRating} interactive={false} size="sm" />
                            <span className="font-bold text-slate-800 text-xs">
                              {s.overallRating ? s.overallRating.toFixed(1) : '0.0'}
                            </span>
                            <span className="text-[11px] text-slate-400">
                              ({s.ratingCount || 0} reviews)
                            </span>
                          </div>
                        </td>

                        {/* User's Submitted Rating */}
                        <td className="px-4 py-4">
                          {hasSubmittedRating ? (
                            <div className="flex items-center gap-2">
                              <StarRating value={s.myRating} interactive={false} size="sm" />
                              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200">
                                {s.myRating} / 5 ★
                              </span>
                            </div>
                          ) : (
                            <span className="text-xs text-slate-400 italic">
                              Not rated yet
                            </span>
                          )}
                        </td>

                        {/* Option to submit a rating / Option to modify their submitted rating */}
                        <td className="px-4 py-4 text-right">
                          {hasSubmittedRating ? (
                            <button
                              onClick={() => handleOpenRatingModal(s)}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 transition-colors"
                              title="Modify your rating"
                            >
                              <Edit3 className="w-3.5 h-3.5 text-amber-600" />
                              <span>Modify Rating</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => handleOpenRatingModal(s)}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 transition-colors"
                              title="Submit rating for this store"
                            >
                              <PlusCircle className="w-3.5 h-3.5 text-indigo-600" />
                              <span>Submit Rating</span>
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* Modal for Submitting or Modifying Rating */}
      <SubmitRatingModal
        isOpen={isRatingModalOpen}
        store={selectedStore}
        onClose={() => {
          setIsRatingModalOpen(false);
          setSelectedStore(null);
        }}
        onSuccess={handleRatingSuccess}
      />
    </div>
  );
};
