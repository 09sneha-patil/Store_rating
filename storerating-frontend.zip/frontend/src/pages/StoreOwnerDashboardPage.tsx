import React, { useState, useEffect } from 'react';
import { Store, Star, Users, RefreshCw, Mail, MapPin, AlertCircle, Calendar } from 'lucide-react';
import { Navbar } from '../components/Navbar';
import { SortableHeader } from '../components/SortableHeader';
import { StarRating } from '../components/StarRating';
import { api } from '../services/api';
import { RatingRecord } from '../types';

export const StoreOwnerDashboardPage: React.FC = () => {
  const [storeData, setStoreData] = useState<any>(null);
  const [hasStore, setHasStore] = useState<boolean>(true);
  const [ratingUsers, setRatingUsers] = useState<RatingRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Sorting
  const [sortBy, setSortBy] = useState('date');
  const [order, setOrder] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {
    loadDashboard();
  }, [sortBy, order]);

  const loadDashboard = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getOwnerDashboard({ sortBy, order });
      if (res.success) {
        setHasStore(res.hasStore);
        if (res.hasStore) {
          setStoreData(res.data);
          setRatingUsers(res.data.ratingUsers || []);
        } else {
          setStoreData(null);
          setRatingUsers([]);
        }
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load store owner dashboard.');
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (field: string) => {
    if (sortBy.toLowerCase() === field.toLowerCase()) {
      setOrder(order === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setOrder(field === 'rating' || field === 'date' ? 'desc' : 'asc');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {/* Page Title */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Store Owner Dashboard
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Monitor your store's average customer rating and reviews
            </p>
          </div>

          <button
            onClick={loadDashboard}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 shadow-sm transition-all"
          >
            <RefreshCw className="w-4 h-4 text-slate-500" />
            <span>Refresh Data</span>
          </button>
        </div>

        {error && (
          <div className="flex items-start gap-2.5 p-4 bg-rose-50 border border-rose-200 text-rose-700 rounded-2xl text-sm">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {!hasStore && !loading && (
          <div className="p-8 bg-amber-50 rounded-2xl border border-amber-200 text-amber-800 text-center space-y-2">
            <Store className="w-12 h-12 text-amber-500 mx-auto" />
            <h3 className="text-lg font-bold">No Store Assigned Yet</h3>
            <p className="text-sm max-w-md mx-auto text-amber-700">
              Your account is registered as a Store Owner, but a System Administrator has not yet linked a store to your profile. Please contact an administrator.
            </p>
          </div>
        )}

        {hasStore && storeData && (
          <>
            {/* Store Header & Stats Grid (Requirements: See average rating of their store) */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Store Details Card */}
              <div className="md:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-3">
                <div className="flex items-center gap-2 text-indigo-600 font-semibold text-xs uppercase tracking-wider">
                  <Store className="w-4 h-4" /> My Store
                </div>
                <h2 className="text-2xl font-black text-slate-900">
                  {storeData.store?.name}
                </h2>
                <div className="space-y-1.5 text-sm text-slate-600 pt-1">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <span>{storeData.store?.email}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-slate-400 mt-0.5" />
                    <span>{storeData.store?.address}</span>
                  </div>
                </div>
              </div>

              {/* Rating Card */}
              <div className="bg-gradient-to-br from-amber-500 to-amber-600 text-white p-6 rounded-2xl shadow-lg shadow-amber-200/60 flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-100">
                    Store Average Rating
                  </span>
                  <div className="flex items-baseline gap-2 mt-2">
                    <span className="text-4xl font-black">
                      {storeData.averageRating ? storeData.averageRating.toFixed(1) : '0.0'}
                    </span>
                    <span className="text-amber-100 text-lg font-semibold">/ 5.0</span>
                  </div>
                  <div className="mt-2">
                    <StarRating value={storeData.averageRating} interactive={false} size="md" />
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-amber-400/40 text-xs text-amber-100 flex items-center justify-between">
                  <span>Total Reviews Received</span>
                  <span className="font-bold text-white text-sm">
                    {storeData.totalRatings || 0}
                  </span>
                </div>
              </div>
            </div>

            {/* List of Users Who Submitted Ratings (Requirement: View a list of users who have submitted ratings for their store with sorting) */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-600" />
                  <span>Customer Ratings & Reviews ({ratingUsers.length})</span>
                </h3>
                <span className="text-xs text-slate-400">
                  Click column headers to sort
                </span>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead className="bg-slate-50/75">
                      <tr>
                        <SortableHeader
                          label="Customer Name"
                          field="name"
                          currentSort={sortBy}
                          currentOrder={order}
                          onSort={handleSort}
                        />
                        <SortableHeader
                          label="Customer Email"
                          field="email"
                          currentSort={sortBy}
                          currentOrder={order}
                          onSort={handleSort}
                        />
                        <th className="px-4 py-3.5 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                          Address
                        </th>
                        <SortableHeader
                          label="Rating Given"
                          field="rating"
                          currentSort={sortBy}
                          currentOrder={order}
                          onSort={handleSort}
                        />
                        <SortableHeader
                          label="Date Submitted"
                          field="date"
                          currentSort={sortBy}
                          currentOrder={order}
                          onSort={handleSort}
                        />
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 bg-white">
                      {loading ? (
                        <tr>
                          <td colSpan={5} className="py-12 text-center text-slate-400">
                            <div className="w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                            Loading customer ratings...
                          </td>
                        </tr>
                      ) : ratingUsers.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-12 text-center text-slate-400">
                            No customers have submitted ratings for your store yet.
                          </td>
                        </tr>
                      ) : (
                        ratingUsers.map((item) => (
                          <tr key={item.ratingId} className="hover:bg-slate-50/60 transition-colors">
                            <td className="px-4 py-3.5 font-bold text-slate-900">
                              {item.name}
                            </td>
                            <td className="px-4 py-3.5 text-slate-600 font-mono text-xs">
                              {item.email}
                            </td>
                            <td className="px-4 py-3.5 text-slate-500 max-w-xs truncate" title={item.address}>
                              {item.address || '—'}
                            </td>
                            <td className="px-4 py-3.5">
                              <div className="flex items-center gap-1.5">
                                <StarRating value={item.rating} interactive={false} size="sm" />
                                <span className="font-bold text-slate-800 text-xs">
                                  {item.rating} / 5
                                </span>
                              </div>
                            </td>
                            <td className="px-4 py-3.5 text-slate-500 text-xs">
                              <div className="flex items-center gap-1">
                                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                                <span>{new Date(item.date).toLocaleDateString()}</span>
                                <span className="text-slate-400">
                                  {new Date(item.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
};
