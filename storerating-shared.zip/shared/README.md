# StoreRate - FullStack Store Rating Platform

A full-stack web application designed for users to submit, modify, and explore ratings (1 to 5 stars) for registered stores. Built with a unified authentication system providing role-based experiences for **System Administrators**, **Normal Users**, and **Store Owners**.

---

## 🛠 Tech Stack

- **Backend**: Express.js with TypeScript, REST API architecture, JWT authentication, bcrypt password hashing.
- **Database**: PostgreSQL (Relational schema with foreign keys, constraints, triggers/checks, and index optimizations).
- **Frontend**: React.js (Vite + TypeScript), Tailwind CSS for modern responsive styling, Lucide React icons, React Router v7.

---

## 👥 User Roles & Implemented Functionalities

### 1. 🛡️ System Administrator
- **Dashboard Overview**:
  - Live metric counter for **Total number of users** (with breakdown by role).
  - Live metric counter for **Total number of stores**.
  - Live metric counter for **Total number of submitted ratings**.
- **Store Management**:
  - View all registered stores with Name, Email, Address, Overall Rating, and Assigned Store Owner.
  - Add new stores (Name 20-60 chars, valid email, address up to 400 chars, optional owner assignment).
  - Search and filter stores by Name, Email, and Address.
  - Column sorting (ascending/descending) on Name, Email, Address, and Rating.
- **User Management**:
  - View list of normal and admin users with Name, Email, Address, Role.
  - **Store Owner Rating**: When viewing a Store Owner, their store's average rating is automatically calculated and displayed.
  - Add new users specifying Name, Email, Password, Address, and Role (`ADMIN`, `USER`, or `STORE_OWNER`).
  - Search and filter users by Name, Email, Address, and Role.
  - Column sorting (ascending/descending) on Name, Email, Address, Role, and Rating.
  - Inspect detailed user profiles in a modal dialog.
- **Session**: Log out from the system securely.

### 2. 👤 Normal User
- **Signup & Authentication**:
  - Self-service registration page with fields: Name, Email, Address, Password.
  - Automatic assignment of the `USER` role.
  - Single login system with JWT tokens.
- **Store Catalog & Ratings**:
  - Browse all registered stores.
  - Real-time search across store **Name** and **Address**.
  - Displays: **Store Name**, **Address**, **Overall Rating** (stars + numeric score + review count), and **User's Submitted Rating**.
  - **Submit Rating**: Submit a 1-5 star rating for any store.
  - **Modify Rating**: Edit an existing rating previously submitted for any store.
  - Interactive Star Rating picker with visual feedback.
  - Column sorting (ascending/descending) on Store Name, Address, Overall Rating, and My Rating.
- **Account**:
  - Update password after logging in (with current password verification).
- **Session**: Log out from the system securely.

### 3. 🏪 Store Owner
- **Dashboard Overview**:
  - View assigned store details (Name, Email, Address).
  - View **average customer rating** of their store (e.g., 4.7 / 5.0) and total review count.
- **Ratings Breakdown**:
  - View list of all users who have submitted ratings for their store (Customer Name, Email, Address, Rating given, Date/Timestamp).
  - Column sorting (ascending/descending) by Name, Email, Rating, and Date.
- **Account**:
  - Update password after logging in.
- **Session**: Log out from the system securely.

---

## 📋 Strict Form Validation Rules

Both frontend client-side validation and backend server-side validation strictly enforce:

| Field | Rule |
|---|---|
| **Name** | Minimum **20** characters, Maximum **60** characters |
| **Address** | Maximum **400** characters, cannot be empty |
| **Password** | **8 to 16** characters, must contain at least **one uppercase letter** and at least **one special character** |
| **Email** | Standard RFC email format |
| **Rating** | Integer between **1** and **5** |

---

## 🗄️ Database Schema Design

The PostgreSQL database (`store_rating_db`) includes three core relational tables:

```sql
-- 1. Users Table
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(60) NOT NULL CHECK (char_length(name) >= 20 AND char_length(name) <= 60),
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  address VARCHAR(400) NOT NULL CHECK (char_length(address) <= 400),
  role VARCHAR(20) NOT NULL CHECK (role IN ('ADMIN', 'USER', 'STORE_OWNER')),
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. Stores Table
CREATE TABLE stores (
  id SERIAL PRIMARY KEY,
  name VARCHAR(60) NOT NULL CHECK (char_length(name) >= 20 AND char_length(name) <= 60),
  email VARCHAR(255) NOT NULL,
  address VARCHAR(400) NOT NULL CHECK (char_length(address) <= 400),
  owner_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Ratings Table
CREATE TABLE ratings (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  store_id INTEGER NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  rating SMALLINT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT unique_user_store_rating UNIQUE (user_id, store_id)
);
```

---

## 🚀 Getting Started & Running the Project

### Prerequisites
- **Node.js** (v18+ recommended)
- **npm** (v9+)
- **PostgreSQL** running on `localhost:5432`

### 1. Database Configuration
Copy `backend/.env.example` to `backend/.env`, then set your PostgreSQL password and replace `JWT_SECRET` with a long, random value. Do not upload `backend/.env` to GitHub; it is ignored by Git.

### 2. Initialize and Seed the Database
Initialize tables and populate sample data:
```bash
# Initialize schema
npm run db:init

# Seed initial stores, users, and ratings
npm run db:seed
```

### 3. Run Automated E2E Tests
Run the 19 automated integration tests:
```bash
npm run test:e2e
```

### 4. Start the Application
Run both backend and frontend development servers:

**Backend (API Server on port 5000):**
```bash
npm run dev
```

**Frontend (Vite Server on port 5173):**
```bash
npm run frontend:dev
```

`npm run backend:dev` is also available as an explicit backend-only command.
Visit **`http://localhost:5173`** in your browser.

---

## 🔑 Pre-Configured Demo Accounts

For instant testing, one-click demo fill buttons are provided directly on the login page:

| Role | Email | Password | Name |
|---|---|---|---|
| **System Administrator** | `admin@storerate.com` | `Admin@1234` | System Administrator Officer |
| **Store Owner** | `owner.david@example.com` | `Owner@1234` | David William Richardson |
| **Store Owner 2** | `owner.eleanor@example.com` | `Owner@1234` | Eleanor Grace Henderson |
| **Normal User 1** | `alice@example.com` | `User@1234` | Alice Elizabeth Johnson |
| **Normal User 2** | `bob@example.com` | `User@1234` | Bob Alexander Martinez |
| **Normal User 3** | `catherine@example.com` | `User@1234` | Catherine Diane Miller |

---

## 📡 REST API Endpoints Summary

### Authentication (`/api/auth`)
- `POST /api/auth/register` - Register a new normal user
- `POST /api/auth/login` - Single login system for all roles
- `GET /api/auth/me` - Fetch profile of current authenticated user
- `PUT /api/auth/change-password` - Update password

### System Administrator (`/api/admin`) - *Requires ADMIN role*
- `GET /api/admin/dashboard` - Total counts of users, stores, and ratings
- `GET /api/admin/stores` - List stores with filtering and sorting
- `POST /api/admin/stores` - Add a new store
- `GET /api/admin/users` - List users with filtering, sorting, and store owner ratings
- `POST /api/admin/users` - Add user with role `ADMIN`, `USER`, or `STORE_OWNER`
- `GET /api/admin/users/:id` - Detailed user info with store rating
- `GET /api/admin/store-owners` - List available store owners for assignment

### Store Listings & Ratings (`/api/stores`) - *Authenticated*
- `GET /api/stores` - List stores with search by Name & Address, overall rating, and user's rating
- `POST /api/stores/ratings` - Submit or modify a rating (1 to 5) (*USER role*)
- `PUT /api/stores/ratings/:storeId` - Modify a rating (*USER role*)
- `GET /api/stores/ratings/my` - Fetch ratings submitted by current user

### Store Owner (`/api/owner`) - *Requires STORE_OWNER role*
- `GET /api/owner/dashboard` - Store details, overall average rating, and sorted list of customer reviews
